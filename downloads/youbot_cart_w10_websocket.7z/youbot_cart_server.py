# pip install websocket-client websocket-server keyboard
import threading
import json
import socket
from websocket_server import WebsocketServer
from controller import Robot, Keyboard as WebotsKeyboard
import keyboard  # For capturing key presses

# Constants
TIME_STEP = 32  # Simulation time step in milliseconds
WHEEL_RADIUS = 0.1  # Radius of the wheels in meters (10cm)
L = 0.471  # Half of the robot's length in meters
W = 0.376  # Half of the robot's width in meters
MAX_VELOCITY = 10.0  # Maximum velocity allowed for the wheels

# Initialize the robot
robot = Robot()

# Initialize the Webots keyboard
webots_keyboard = WebotsKeyboard()
webots_keyboard.enable(TIME_STEP)

# Get motor devices
wheel1 = robot.getDevice("wheel1")  # Front-right wheel
wheel2 = robot.getDevice("wheel2")  # Front-left wheel
wheel3 = robot.getDevice("wheel3")  # Rear-right wheel
wheel4 = robot.getDevice("wheel4")  # Rear-left wheel

# Set motors to velocity control mode
for wheel in [wheel1, wheel2, wheel3, wheel4]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

# Shared state
last_velocities = [0, 0, 0, 0]
paused = False


def set_wheel_velocity(v1, v2, v3, v4):
    """Set the velocity of all wheels."""
    wheel1.setVelocity(v1)
    wheel2.setVelocity(v2)
    wheel3.setVelocity(v3)
    wheel4.setVelocity(v4)


# Custom WebSocket server class to support IPv6
class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6
        super().__init__(host=host, port=port)


# WebSocket message handler
def on_message(client, server, message):
    global last_velocities, paused
    try:
        data = json.loads(message)
        direction = data.get("direction")

        if direction == "UP":
            last_velocities = [MAX_VELOCITY] * 4
            set_wheel_velocity(*last_velocities)
            paused = False
        elif direction == "DOWN":
            last_velocities = [-MAX_VELOCITY] * 4
            set_wheel_velocity(*last_velocities)
            paused = False
        elif direction == "LEFT":
            last_velocities = [-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY]
            set_wheel_velocity(*last_velocities)
            paused = False
        elif direction == "RIGHT":
            last_velocities = [MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY]
            set_wheel_velocity(*last_velocities)
            paused = False
        elif direction == "STOP" or direction == "PAUSE":
            set_wheel_velocity(0, 0, 0, 0)
            paused = True
        elif direction == "RESUME":
            if paused:
                set_wheel_velocity(*last_velocities)
                paused = False
    except json.JSONDecodeError:
        print("Invalid message received. Expected JSON format.")
    except Exception as e:
        print(f"Error handling message: {e}")


# WebSocket server thread
def start_websocket_server():
    server_ip = "2001:288:6004:17:fff1:cd25:0000:a056"  # Replace with your IPv6
    server_port = 8081

    try:
        server = IPv6WebsocketServer(host=server_ip, port=server_port)
        server.set_fn_message_received(on_message)
        print(f"WebSocket server started on [{server_ip}]:{server_port}, waiting for commands...")
        server.run_forever()
    except Exception as e:
        print(f"Failed to start WebSocket server: {e}")


# Arrow key control thread
def start_arrow_key_control():
    global last_velocities, paused
    print("Use arrow keys to control the robot (↑ ↓ ← →). Press 'P' to pause, 'R' to resume, 'ESC' to quit.")
    while True:
        try:
            if keyboard.is_pressed("up"):
                print("Arrow Key: UP")
                last_velocities = [MAX_VELOCITY] * 4
                set_wheel_velocity(*last_velocities)
                paused = False
            elif keyboard.is_pressed("down"):
                print("Arrow Key: DOWN")
                last_velocities = [-MAX_VELOCITY] * 4
                set_wheel_velocity(*last_velocities)
                paused = False
            elif keyboard.is_pressed("left"):
                print("Arrow Key: LEFT")
                last_velocities = [-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY]
                set_wheel_velocity(*last_velocities)
                paused = False
            elif keyboard.is_pressed("right"):
                print("Arrow Key: RIGHT")
                last_velocities = [MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY]
                set_wheel_velocity(*last_velocities)
                paused = False
            elif keyboard.is_pressed("p"):
                if not paused:
                    print("Paused (P key pressed).")
                    set_wheel_velocity(0, 0, 0, 0)
                    paused = True
            elif keyboard.is_pressed("r"):
                if paused:
                    print("Resumed (R key pressed).")
                    set_wheel_velocity(*last_velocities)
                    paused = False
            elif keyboard.is_pressed("esc"):
                print("Exiting arrow key control...")
                set_wheel_velocity(0, 0, 0, 0)
                break
        except Exception as e:
            print(f"Error in arrow key control: {e}")
            break


# Webots simulation thread
def start_webots_simulation():
    try:
        while robot.step(TIME_STEP) != -1:
            pass
    except Exception as e:
        print(f"Simulation error: {e}")


# Main
if __name__ == "__main__":
    websocket_thread = threading.Thread(target=start_websocket_server, daemon=True)
    simulation_thread = threading.Thread(target=start_webots_simulation, daemon=True)
    arrow_key_thread = threading.Thread(target=start_arrow_key_control, daemon=True)

    websocket_thread.start()
    simulation_thread.start()
    arrow_key_thread.start()

    try:
        while True:
            pass
    except KeyboardInterrupt:
        print("Shutting down gracefully...")